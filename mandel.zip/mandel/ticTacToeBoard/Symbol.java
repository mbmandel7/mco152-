package mandel.ticTacToeBoard;

public enum Symbol {

	X, O;

}
