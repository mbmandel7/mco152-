package mandel.mtaMap;

import java.io.IOException;

import org.junit.Test;

public class RoutesTest {

	@Test
	public void testInstantiateRoutes() throws IOException {
		new Routes();
	}
}
