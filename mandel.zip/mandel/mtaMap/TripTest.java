package mandel.mtaMap;

import org.junit.Test;

public class TripTest {

	@Test
	public void testInstantiateTrip() {
		new Trip("111", "222");
	}

}
