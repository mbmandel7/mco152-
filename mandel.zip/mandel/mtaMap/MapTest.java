package mandel.mtaMap;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.junit.Test;

public class MapTest {

	@Test
	public void testInstantiateMap() throws FileNotFoundException, IOException {
		new Map();
	}

}
