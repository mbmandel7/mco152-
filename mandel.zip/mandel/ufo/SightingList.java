package mandel.ufo;

import java.util.ArrayList;

public class SightingList extends ArrayList<Sighting> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5903814652693171801L;

}
