package mandel.ufo;

import org.junit.Test;

public class ZipCodeTest {

	@Test
	public void testInstantiateZipCode() {
		new ZipCode("11230", 40.5, -73.2, "Brooklyn", "NY");
	}

}
